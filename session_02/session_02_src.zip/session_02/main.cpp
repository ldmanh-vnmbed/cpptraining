#include <iostream>

int main(int, char**) {
    std::cout << "Hello IoT Lab members!\n";
    std::cout << "Welcome to the C++ training session.\n";
    
    return 0;
}
