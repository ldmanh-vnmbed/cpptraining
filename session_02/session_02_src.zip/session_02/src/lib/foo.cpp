#include <iostream>
#include "foo.h"

void foo()
{
    std::cout << "Hello World!\n";
}

