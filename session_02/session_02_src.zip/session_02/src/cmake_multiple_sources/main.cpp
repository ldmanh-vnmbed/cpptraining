#include "foo.h"

int main()
{
    foo();
    return 0;
}
